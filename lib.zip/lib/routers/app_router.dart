import 'package:freshmeals/models/facebook_user.dart';
import 'package:freshmeals/models/home/address_model.dart';
import 'package:freshmeals/views/appointment/appointments_booking.dart';
import 'package:freshmeals/views/appointment/my_appointments.dart';
import 'package:freshmeals/views/auth/facebook_login.dart';
import 'package:freshmeals/views/homepage/account_info.dart';
import 'package:freshmeals/views/homepage/adress_picker.dart';
import 'package:freshmeals/views/homepage/delively_addresses.dart';
import 'package:freshmeals/views/homepage/checkout_screen.dart';
import 'package:freshmeals/views/homepage/favorites_screen.dart';
import 'package:freshmeals/views/homepage/homepage.dart';
import 'package:freshmeals/views/homepage/location_track.dart';
import 'package:freshmeals/views/homepage/luch_screen.dart';
import 'package:freshmeals/views/homepage/meal_details.dart';
import 'package:freshmeals/views/homepage/payment_method.dart';
import 'package:freshmeals/views/homepage/payments/failed_screen.dart';
import 'package:freshmeals/views/homepage/payments/my_payments.dart';
import 'package:freshmeals/views/homepage/payments/processing_screen.dart';
import 'package:freshmeals/views/homepage/payments/subscribed.dart';
import 'package:freshmeals/views/homepage/payments/sucess_screen.dart';
import 'package:freshmeals/views/homepage/product_details_add_to_cart.dart';
import 'package:freshmeals/views/homepage/subscribe_screen.dart';
import 'package:freshmeals/views/welcome/ages_screen.dart';
import 'package:freshmeals/views/welcome/gender_screen.dart';
import 'package:freshmeals/views/welcome/goal_screen.dart';
import 'package:freshmeals/views/welcome/height_input.dart';
import 'package:freshmeals/views/welcome/other_information.dart';
import 'package:freshmeals/views/welcome/preferances_screen.dart';
import 'package:freshmeals/views/welcome/subscription.dart';
import 'package:freshmeals/views/welcome/welcome.dart';
import 'package:go_router/go_router.dart';
import '../models/user_model.dart';
import '../views/auth/forgot_password.dart';
import '../views/auth/login.dart';
import '../views/auth/new_password.dart';
import '../views/auth/register.dart';
import '../views/auth/reset_password.dart';
import '../views/homepage/my_order.dart';
import '../views/homepage/my_order_details.dart';
import '../views/homepage/calorie_tracker.dart';
import '../views/splash/splash.dart';
import '../views/welcome/weight_input.dart';

final GoRouter router = GoRouter(routes: [
  GoRoute(path: '/', builder: (context, state) => const SplashScreen()),
  GoRoute(
    path: '/login',
    builder: (context, state) => const SigninScreen(),
  ),
  GoRoute(
    path: '/newUser',
    builder: (context, state) => const RegisterScreen(),
  ),
  GoRoute(
    path: '/facebookRegister',
    builder: (context, state) {
      final facebookUser = state.extra as FacebookUser;
      return FacebookRegisterScreen(facebookUser: facebookUser);
    },
  ),
  GoRoute(
    path: '/forgetPassword',
    builder: (context, state) => const ForgotPassword(),
  ),

  GoRoute(
    path: '/resetPassword/:identifier',
    builder: (context, state) {
      // Retrieve the mealId from the route parameters
      final category = state.pathParameters['identifier']!;
      return ResetPasswordScreen(identifier: category);
    },
  ),
  GoRoute(
    path: '/newPassword',
    builder: (context, state) {
      final userModel = state.extra as Reset;
      return NewPasswordScreen(resetData: userModel);
    },
  ),
  GoRoute(
    path: '/age',
    builder: (context, state) {
      final userModel = state.extra as UserModel;
      return AgeScreen(user: userModel);
    },
  ),
  GoRoute(
    path: '/goal',
    builder: (context, state) {
      final userModel = state.extra as UserModel;
      return HealthGoalScreen(user: userModel);
    },
  ),
  GoRoute(
    path: '/gender',
    builder: (context, state) {
      final userModel = state.extra as UserModel;
      return GenderScreen(user: userModel);
    },
  ),
  GoRoute(
      path: '/height',
      builder: (context, state) {
        final userModel = state.extra as UserModel;
        return HeightInputScreen(user: userModel);
      }),
  GoRoute(
      path: '/weight',
      builder: (context, state) {
        final userModel = state.extra as UserModel;
        return WeightInputScreen(user: userModel);
      }),
  GoRoute(
    path: '/welcome',
    builder: (context, state) => const WelcomeScreen(),
  ),
  GoRoute(
      path: '/subscription',
      builder: (context, state) {
        final userModel = state.extra as UserModel?;
        return SubscriptionScreen(user: userModel);
      }),
  GoRoute(
      path: '/preferences',
      builder: (context, state) {
        final userModel = state.extra as UserModel;
        return PreferencesScreen(user: userModel);
      }),
  GoRoute(
      path: '/additional',
      builder: (context, state) {
        final userModel = state.extra as UserModel;
        return AdditionalInformationScreen(user: userModel);
      }),
  GoRoute(
    path: '/home',
    builder: (context, state) => const Homepage(),
  ),
  // GoRoute(
  //   path: '/lunch',
  //   builder: (context, state) => LunchPage(),
  // ),

  GoRoute(
    path: '/lunch/:typeId/:title',
    builder: (context, state) {
      final typeId = state.pathParameters['typeId'] ?? '0';
      final title = state.pathParameters['title'] ?? 'Recommended';

      return LunchPage(typeId: typeId, title: title);
    },
  ),
  GoRoute(
    path: '/productDetails',
    builder: (context, state) => ProductDetailPage(),
  ),
  GoRoute(
    path: '/mealDetails/:mealId',
    builder: (context, state) {
      // Retrieve the mealId from the route parameters
      final mealId = state.pathParameters['mealId']!;
      return MealDetailScreen(mealId: mealId);
    },
  ),

  GoRoute(
      path: '/newAddress',
      builder: (context, state) {
        final addressModel = state.extra as Address?;
        return AddressPickerScreen(address: addressModel);
      }),
  GoRoute(
    path: '/checkout',
    builder: (context, state) => const CheckOutScreen(),
  ),
  GoRoute(
    path: '/changeAddress',
    builder: (context, state) => ChangeAddress(),
  ),
  GoRoute(
    path: '/myOrderDetails/:orderId',
    builder: (context, state) {
      final orderId = state.pathParameters['orderId']!;
      return MyOrderDetailsScreen(orderId: orderId);
    },
  ),
  GoRoute(
    path: '/myOrder',
    builder: (context, state) => const MyOrderScreen(),
  ),
  GoRoute(
    path: '/trackLocation',
    builder: (context, state) => LocationTrackScreen(),
  ),
  GoRoute(
    path: '/accountInfo',
    builder: (context, state) => const AccountInfoScreen(),
  ),
  GoRoute(
    path: '/paymentMethod',
    builder: (context, state) => const PaymentMethodScreen(),
  ),
  GoRoute(
    path: '/booking',
    builder: (context, state) => const AppointmentsScreen(),
  ),
  GoRoute(
    path: '/myAppointments',
    builder: (context, state) => const MyAppointmentsScreen(),
  ),
  GoRoute(
    path: '/favorites',
    builder: (context, state) => const FavoritesScreen(),
  ),
  GoRoute(
    path: '/success',
    builder: (context, state) => const SuccessScreen(),
  ),
  GoRoute(
    path: '/failed',
    builder: (context, state) => const FailedScreen(),
  ),
  GoRoute(
    path: '/subscribe',
    builder: (context, state) => const SubscribeScreen(),
  ),
  GoRoute(
    path: '/subscribed',
    builder: (context, state) => const SubscribedScreen(),
  ),
  GoRoute(
    path: '/trackCalories',
    builder: (context, state) => const CalorieTrackerPage(),
  ),
  GoRoute(
    path: '/processing/:invoice/:subscribing',
    builder: (context, state) {
      final invoiceNo = state.pathParameters['invoice']!;
      final subscribingString = state.pathParameters['subscribing'] ?? 'false';
      final subscribing = subscribingString.toLowerCase() == 'true';

      return ProcessingScreen(invoiceNo: invoiceNo, subscribing: subscribing);
    },
  ),
  GoRoute(
    path: '/payments',
    builder: (context, state) => const PaymentsScreen(),
  ),
  GoRoute(
    path: '/payments',
    builder: (context, state) => const PaymentsScreen(),
  ),
]);
