class AssetsUtils {
  static const logo = "assets/images/7.png";
  static const mars = "assets/images/mars.png";
  static const venus = "assets/images/venus.png";
  static const order = "assets/images/Artwork.png";
  static const nutri = "assets/images/Artwork@2x.png";
  static const derivered = "assets/images/Artwork (1).png";
  static const empty = "assets/images/empty.png";
  ////
  static const drinks = "assets/images/drinks.png";
  static const healthy = "assets/images/healthy.png";
  static const fish = "assets/images/fish.png";
  static const fruits = "assets/images/fruitss.png";
  static const meat = "assets/images/meat.png";
  static const medicine = "assets/images/medicine.png";
  static const nuts = "assets/images/Nuts.png";
  static const pasta = "assets/images/pasta.png";
  static const vegetables = "assets/images/vegetabless.png";
////
  static const lunch = "assets/images/lunch.png";
  static const salad = "assets/images/salad.png";
  static const snack = "assets/images/snack.png";
  static const banner = "assets/images/Banner.png";
  static const breakfast = "assets/images/breakfast.png";
  static const dinner = "assets/images/dinner.png";
  static const rectangle = "assets/images/Rectangle.png";
  static const profile =
      "assets/images/Screenshot 2024-12-27 at 2.46.10 PM.png";
  static const success = "assets/images/Group 721.png";
  static const emptyLogo = "assets/images/empty-folder.png";
  static const location = "assets/images/location.png";
  static const failed = "assets/images/failed.png";
  static const subscribed = "assets/images/success.png";
}
