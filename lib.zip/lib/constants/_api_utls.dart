const String baseUrl = "https://freshmeals.rw/api/";
const String mapKy = "AIzaSyCd8042Lj-wdIbCWAsvRp-FctZh3rKKS-s";